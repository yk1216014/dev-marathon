const config = {
  apiUrl: 'http://localhost:5465'
};

export default config;