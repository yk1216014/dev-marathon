const getApiUrl = () => {
  return '';
};

const config = {
  apiUrl: getApiUrl()
};

export default config;